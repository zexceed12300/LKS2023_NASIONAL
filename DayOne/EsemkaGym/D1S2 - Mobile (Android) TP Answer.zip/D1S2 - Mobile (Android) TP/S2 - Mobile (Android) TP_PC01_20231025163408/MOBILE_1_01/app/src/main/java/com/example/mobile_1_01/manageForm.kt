package com.example.mobile_1_01

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class manageForm : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_form)

        val btnOut: Button = findViewById(R.id.btnOut4)
        val btDaily: Button = findViewById(R.id.btnDaily)
        val btMember: Button = findViewById(R.id.btnMember)
        val btReport: Button = findViewById(R.id.btnReport)

        btDaily.setOnClickListener {
            val intent = Intent(this, adminForm::class.java)
            startActivity(intent)
        }

        btReport.setOnClickListener {
            val intent = Intent(this, reportForm::class.java)
            startActivity(intent)
        }

        btnOut.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}