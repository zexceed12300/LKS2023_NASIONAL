package com.example.mobile_1_01

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etEmails: EditText = findViewById(R.id.etEmail)
        val etPassword: EditText = findViewById(R.id.etPass)
        val btnIn: Button = findViewById(R.id.btIn)
        val tViewUp: TextView = findViewById(R.id.tvUp)

        tViewUp.setOnClickListener {
            // Open Sign Up
            val intent = Intent(this, signUpForm::class.java)
            startActivity(intent)
        }

        btnIn.setOnClickListener {
            // Do sign in
            if(etEmails.text.toString() != ""){
                if(etPassword.text.toString() != ""){
                    // Run Code
                    val LogInURL = URL("http://10.0.2.2:8081/api/login")

                    thread {
                        try{
                            val connection = LogInURL.openConnection() as HttpURLConnection
                            connection.requestMethod = "POST"

                            connection.setRequestProperty("Content-Type", "application/json")

                            val requestBody = """
                            {
                                "email": "${etEmails.text}",
                                "password": "${etPassword.text}"
                            }
                            """.trimIndent()

                            val os = connection.outputStream
                            os.write(requestBody.toByteArray(Charsets.UTF_8))

                            val responseCode = connection.responseCode
                            if(responseCode == HttpURLConnection.HTTP_OK){
                                val response = connection.inputStream.bufferedReader().readText()
                                val jsonObject = JSONObject(response)

                                val jsonObject2 = JSONObject(jsonObject.getString("user"))

                                if(jsonObject2.getString("admin") == "true") {
                                    val token = jsonObject.getString("token")

                                    // !!!!!!!!!!
                                    val bundle = Bundle()
                                    bundle.putString("token", token)

                                    val intent = Intent(this, adminForm::class.java)
                                    intent.putExtras(bundle)
                                    startActivity(intent)
                                    // !!!!!!!!!!
                                }else if (jsonObject2.getString("joinedMemberAt") == "null"){
                                    val intent = Intent(this, memberNotPaid::class.java)
                                    startActivity(intent)
                                } else if (jsonObject2.getString("admin") != "true") {
                                    val intent = Intent(this, memberForm::class.java)
                                    startActivity(intent)
                                }
                            } else if (responseCode.toString() == "400") {
                                runOnUiThread{Toast.makeText(this, "Invalid Login!", Toast.LENGTH_SHORT).show()}
                            } else {
                                runOnUiThread{Toast.makeText(this, "Something went wrong!", Toast.LENGTH_SHORT).show()}
                            }
                        } catch (e: Exception) {
                            Log.d("Response", e.message.toString())
                        }
                    }
                } else {
                    Toast.makeText(this, "Please fill in your password", Toast.LENGTH_SHORT).show()
                }
            } else{
                Toast.makeText(this, "Please fill in your email", Toast.LENGTH_SHORT).show()
            }
        }
    }
}