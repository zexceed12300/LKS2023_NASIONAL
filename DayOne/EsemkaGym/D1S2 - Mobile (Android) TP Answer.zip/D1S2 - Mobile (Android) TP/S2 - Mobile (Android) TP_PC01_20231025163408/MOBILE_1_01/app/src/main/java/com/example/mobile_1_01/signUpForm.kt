package com.example.mobile_1_01

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class signUpForm : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up_form)

        val etEmail: EditText = findViewById(R.id.etEmail2)
        val etPass: EditText = findViewById(R.id.etPassword2)
        val etName: EditText = findViewById(R.id.etName2)
        val rbMale: RadioButton = findViewById(R.id.rbMale2)
        val rbFemale: RadioButton = findViewById(R.id.rbFemale2)
        val btnUp: Button = findViewById(R.id.btUp2)
        val tvIn: TextView = findViewById(R.id.tvIn2)

        tvIn.setOnClickListener {
            // Open MainActivity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        btnUp.setOnClickListener {
            if(etEmail.text.toString() != "") {
                if(etPass.text.toString() != "") {
                    if(etName.text.toString() != "") {
                        if(!rbMale.isChecked && !rbFemale.isChecked) {
                            Toast.makeText(this, "Please pick a gender", Toast.LENGTH_SHORT).show()
                        } else {
                            if(rbMale.isChecked){
                                val gender = "male"

                                signUp(etEmail.text.toString(), gender, etName.text.toString(), etPass.text.toString())
                            } else if (rbFemale.isChecked) {
                                val gender = "female"

                                signUp(etEmail.text.toString(), gender, etName.text.toString(), etPass.text.toString())
                            } else {
                                Log.d("Response", "Something went wrong!")
                            }
                        }
                    } else {
                        Toast.makeText(this, "Please fill in your name", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "Please fill in your password", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please fill in your email", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun signUp(etEmail: String, gender: String, etName: String, etPassword: String) {
        try{
            val SignUpURL = URL("http://10.0.2.2:8081/api/signup")
            thread{
                val connection = SignUpURL.openConnection() as HttpURLConnection
                connection.requestMethod = "POST"

                connection.setRequestProperty("Content-Type", "application/json")

                val requestBody = """
                {
                    "email": "${etEmail}",
                    "gender": "${gender}",
                    "name": "${etName}",
                    "password": "${etPassword}"
                }
                """.trimIndent()

                val os = connection.outputStream
                os.write(requestBody.toByteArray(Charsets.UTF_8))

                val responseCode = connection.responseCode
                if(responseCode == HttpURLConnection.HTTP_OK){
                    val response = connection.inputStream.bufferedReader().readText()
                    Log.d("Response", response)

                    runOnUiThread{Toast.makeText(this, "Registration complete! Enter your email and password in the sign in page to login", Toast.LENGTH_LONG).show()}

                    /*val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)*/
                }
                else {
                    Log.d("Response", responseCode.toString())
                }
            }
        } catch (e: Exception) {
            Log.d("Response", e.message.toString())
        }
    }
}