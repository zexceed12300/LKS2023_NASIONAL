package com.example.mobile_1_01

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class reportForm : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_report_form)

        val btnOut: Button = findViewById(R.id.btnOut2)
        val btDaily: Button = findViewById(R.id.btnDaily)
        val btMember: Button = findViewById(R.id.btnMember)
        val btReport: Button = findViewById(R.id.btnReport)

        btMember.setOnClickListener {
            val intent = Intent(this, manageForm::class.java)
            startActivity(intent)
        }

        btDaily.setOnClickListener {
            val intent = Intent(this, adminForm::class.java)
            startActivity(intent)
        }

        btnOut.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}