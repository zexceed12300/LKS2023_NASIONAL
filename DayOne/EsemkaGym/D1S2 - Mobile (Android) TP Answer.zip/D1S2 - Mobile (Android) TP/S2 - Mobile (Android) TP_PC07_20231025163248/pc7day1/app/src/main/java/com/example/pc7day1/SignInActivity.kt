package com.example.pc7day1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.example.pc7day1.databinding.ActivitySigninBinding
import com.example.pc7day1.databinding.ActivityUserBinding
import com.google.android.material.snackbar.Snackbar
import org.json.JSONObject
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executor
import java.util.concurrent.Executors

class SignInActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySigninBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySigninBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSignUp.setOnClickListener {
            startActivity(Intent(this@SignInActivity, SignUpActivity::class.java))
        }

        binding.btnSignIn.setOnClickListener {
            signInProses()
        }
    }

    private fun signInProses() {
        if (binding.etEmail.text.toString().isEmpty() || binding.etPassword.text.toString()
                .isEmpty()
        ) {
            Snackbar.make(binding.root, "Data can't empty", Snackbar.LENGTH_SHORT).show()
        } else {
            val executor: Executor = Executors.newSingleThreadExecutor()
            executor.execute {
                val url = URL("${GlobalData.url}/api/login")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-type", "application/json; charset=UTF-8")
                conn.connectTimeout = 5000
                conn.doOutput = true

                val outputStream = DataOutputStream(conn.outputStream)
                val jsonObject = JSONObject()
                jsonObject.put("email", binding.etEmail.text)
                jsonObject.put("password", binding.etPassword.text)
                val requestBody = jsonObject.toString()
                outputStream.writeBytes(requestBody)
                outputStream.flush()
                outputStream.close()

                if (conn.responseCode == 200) {
                    val reader = BufferedReader(InputStreamReader(conn.inputStream))
                    val response = StringBuilder()

                    var line: String?

                    while (reader.readLine().also { line = it } != null) {
                        response.append(line)
                    }

                    val jsonResponse = JSONObject(response.toString())
                    val token = jsonResponse.getString("token")
                    GlobalData.token = token

                    val user = jsonResponse.optJSONObject("user")
                    val joinedMemberAt = user.getString("joinedMemberAt")
                    val admin = user.getString("admin")

                    if (joinedMemberAt.toString() == "null") {
                        startActivity(Intent(this@SignInActivity, YourRegisteredActivity::class.java))
                        Log.d("r", joinedMemberAt)

                    } else {

                        if (admin.toString() == "false") {
                            startActivity(Intent(this@SignInActivity, ActivityUserBinding::class.java))
                        } else {
                            startActivity(Intent(this@SignInActivity, AdminDailyCodeActivity::class.java))
                        }
                        Log.d("r", admin)
                        Log.d("r", joinedMemberAt)
                    }

                } else {
                    Snackbar.make(binding.root, "Username or password is wrong!", Snackbar.LENGTH_SHORT).show()
                }
            }
        }
    }
}