package com.example.pc7day1.user

class User : ArrayList<UserItem>()