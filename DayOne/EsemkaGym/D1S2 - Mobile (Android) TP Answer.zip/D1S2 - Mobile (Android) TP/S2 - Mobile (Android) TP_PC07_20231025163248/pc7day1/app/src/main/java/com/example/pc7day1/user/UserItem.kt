package com.example.pc7day1.user

data class UserItem(
    val admin: Boolean,
    val email: String,
    val gender: String,
    val id: Int,
    val joinedMemberAt: Any,
    val membershipEnd: Any,
    val name: String,
    val password: String,
    val registerAt: String
)