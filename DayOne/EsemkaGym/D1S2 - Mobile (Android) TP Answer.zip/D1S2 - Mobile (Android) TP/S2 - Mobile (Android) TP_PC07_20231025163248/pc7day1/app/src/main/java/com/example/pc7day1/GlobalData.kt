package com.example.pc7day1

object GlobalData {
    val url = "http://10.0.2.2:8081"
    var token: String = ""
}