package com.example.pc7day1

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.pc7day1.databinding.ActivitySignupBinding
import com.example.pc7day1.databinding.YourRegisteredBinding

class YourRegisteredActivity: AppCompatActivity() {
    private lateinit var binding: YourRegisteredBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = YourRegisteredBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}