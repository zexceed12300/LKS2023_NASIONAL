package com.example.pc7day1

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.pc7day1.databinding.ActivityAdminDailycodeBinding
import com.example.pc7day1.databinding.YourRegisteredBinding
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Date
import java.util.concurrent.Executor
import java.util.concurrent.Executors

class AdminDailyCodeActivity: AppCompatActivity() {
    private lateinit var binding: ActivityAdminDailycodeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdminDailycodeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadCode()

        binding.btnManageMember.setOnClickListener {
            startActivity(Intent(this@AdminDailyCodeActivity, ManageMemberApprovedActivity::class.java))
        }
    }

    private fun loadCode() {
        val executor: Executor = Executors.newSingleThreadExecutor()
        executor.execute {
            val url = URL("${GlobalData.url}/api/attendance/checkin/code")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.setRequestProperty("Authorization", "Bearer ${GlobalData.token}")

            Log.d("r", conn.responseCode.toString())
            if (conn.responseCode == 200) {
                val reader = BufferedReader(InputStreamReader(conn.inputStream))
                val response = StringBuilder()

                var line: String?

                while (reader.readLine().also { line = it } != null) {
                    response.append(line)
                }

                val jsonResponse = JSONObject(response.toString())
                val code = jsonResponse.getString("code")
                Log.d("r", code)

                runOnUiThread {
                    binding.tvDailyCode.text = code
                }
            }
        }
    }
}