package com.example.pc7day1

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.pc7day1.databinding.ActivitySigninBinding
import com.example.pc7day1.databinding.ActivitySignupBinding
import com.google.android.material.snackbar.Snackbar
import org.json.JSONObject
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executor
import java.util.concurrent.Executors

class SignUpActivity: AppCompatActivity() {
    private lateinit var binding: ActivitySignupBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSignUp.setOnClickListener {
            signUpProses()
        }

        binding.cbMale.setOnCheckedChangeListener { _, isChecked ->
            if (binding.cbMale.isChecked) {
                binding.cbFemale.isChecked = false
            }
        }

        binding.cbFemale.setOnCheckedChangeListener { _, isChecked ->
            if (binding.cbFemale.isChecked) {
                binding.cbMale.isChecked = false
            }
        }
    }

    private fun signUpProses() {
        if (binding.etEmail.text.toString().isEmpty() || binding.etPassword.text.toString().isEmpty() || binding.etName.text.toString().isEmpty() || (!binding.cbMale.isChecked && !binding.cbFemale.isChecked)) {
            Snackbar.make(binding.root, "Data can't empty!", Snackbar.LENGTH_SHORT).show()
        } else {
            val executor: Executor = Executors.newSingleThreadExecutor()
            executor.execute {
                val url = URL("${GlobalData.url}/api/signup")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-type", "application/json; charset=UTF-8")
                conn.connectTimeout = 5000
                conn.doOutput = true

                val outputStream = DataOutputStream(conn.outputStream)
                val jsonObject = JSONObject()
                jsonObject.put("name", binding.etName.text)
                jsonObject.put("email", binding.etEmail.text)
                jsonObject.put("password", binding.etPassword.text)
                if (binding.cbMale.isChecked) {
                    jsonObject.put("gender", "Male")
                } else {
                    jsonObject.put("gender", "Female")
                }
                val requestBody = jsonObject.toString()
                outputStream.writeBytes(requestBody)
                outputStream.flush()
                outputStream.close()

                if (conn.responseCode == 200) {
                    runOnUiThread {
                        Toast.makeText(this@SignUpActivity, "Registration completes! Enter your email and password to login", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this@SignUpActivity, SignInActivity::class.java)
                        startActivity(intent)
                    }
                } else {
                    Log.d("r", "gagal")
                }
            }
        }
    }
}