package com.example.pc7day1.approval

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.pc7day1.R
import com.example.pc7day1.user.UserItem

class ApprovalAdapter(private val userItem: List<UserItem>, private val confirm: (memberId: Int) -> Unit): RecyclerView.Adapter<ApprovalAdapter.Viewholder>() {
    inner class Viewholder(itemView: View): RecyclerView.ViewHolder(itemView) {
        val username: TextView = itemView.findViewById(R.id.tvUserName)
        val registerAt: TextView = itemView.findViewById(R.id.tvRegisterAt)
        val btnConfirm: Button = itemView.findViewById(R.id.btnConfirm)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Viewholder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.approval_item, parent, false)
        return Viewholder(view)
    }

    override fun getItemCount(): Int {
        return userItem.size
    }

    override fun onBindViewHolder(holder: Viewholder, position: Int) {
        val item = userItem[position]

        holder.username.text = item.name
        holder.registerAt.text = "Register at " + item.registerAt

        holder.btnConfirm.setOnClickListener {
            confirm(item.id)
        }
    }
}