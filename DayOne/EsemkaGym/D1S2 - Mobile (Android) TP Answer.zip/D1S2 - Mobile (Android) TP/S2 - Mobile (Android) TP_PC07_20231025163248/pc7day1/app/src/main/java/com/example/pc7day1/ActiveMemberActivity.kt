package com.example.pc7day1

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.pc7day1.approval.ActiveAdapter
import com.example.pc7day1.databinding.ActivityAdminActivemembersBinding
import com.example.pc7day1.databinding.ActivityAdminApprovedBinding
import com.example.pc7day1.user.UserItem
import org.json.JSONArray
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executor
import java.util.concurrent.Executors

class ActiveMemberActivity: AppCompatActivity() {
    private lateinit var binding: ActivityAdminActivemembersBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdminActivemembersBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadData()

        binding.btnPending.setOnClickListener {
            startActivity(Intent(this@ActiveMemberActivity, ManageMemberApprovedActivity::class.java))
        }
    }

    private fun loadData() {
        val executor: Executor = Executors.newSingleThreadExecutor()
        executor.execute {
            val url = URL("${GlobalData.url}/api/member?status=ACTIVE")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.setRequestProperty("Authorization", "Bearer ${GlobalData.token}")

            if (conn.responseCode == 200) {
                val reader = BufferedReader(InputStreamReader(conn.inputStream))
                val response = StringBuilder()

                var line: String?

                while (reader.readLine().also { line = it } != null) {
                    response.append(line)
                }

                val jsonResponse = JSONArray(response.toString())
                if (jsonResponse != null) {
                    val dataUserList = mutableListOf<UserItem>()

                    for (i in 0 until jsonResponse.length()) {
                        val dataUserObject = jsonResponse.optJSONObject(i)

                        val dataUserItem = UserItem(
                            admin = dataUserObject.getBoolean("admin"),
                            email = dataUserObject.getString("email"),
                            gender = dataUserObject.getString("gender"),
                            id = dataUserObject.getInt("id"),
                            joinedMemberAt = dataUserObject.getString("joinedMemberAt"),
                            membershipEnd = dataUserObject.getString("membershipEnd"),
                            name = dataUserObject.getString("name"),
                            password = dataUserObject.getString("password"),
                            registerAt = dataUserObject.getString("registerAt")
                        )
                        dataUserList.add(dataUserItem)
                    }
                    runOnUiThread {
                        setUpGv(dataUserList)
                    }
                }
            }
        }
    }

    private fun setUpGv(dataUserList: MutableList<UserItem>) {
        val rv = binding.rv
        val layoutManager = LinearLayoutManager(this@ActiveMemberActivity)
        rv.layoutManager = layoutManager
        val adapter = ActiveAdapter(dataUserList)
        rv.adapter = adapter
    }
}