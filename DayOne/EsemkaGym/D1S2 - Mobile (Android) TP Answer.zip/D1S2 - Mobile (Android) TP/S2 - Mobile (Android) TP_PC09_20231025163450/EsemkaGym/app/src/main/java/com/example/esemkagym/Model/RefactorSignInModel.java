package com.example.esemkagym.Model;

public class RefactorSignInModel {
    String token;
    String email;

    public RefactorSignInModel() {
    }

    public RefactorSignInModel(String token, String email) {
        this.token = token;
        this.email = email;
    }

    public String getToken() {
        return token;
    }

    public String getEmail() {
        return email;
    }
}
