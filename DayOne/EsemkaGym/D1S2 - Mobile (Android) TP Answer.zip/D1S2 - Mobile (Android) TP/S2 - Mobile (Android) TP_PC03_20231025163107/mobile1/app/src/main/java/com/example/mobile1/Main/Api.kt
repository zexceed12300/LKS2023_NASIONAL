package com.example.mobile1.Main

object Api {
    var token: String? = null
    val api: String = "http://10.0.2.2:8081/api/"
    val email: String? = null
}