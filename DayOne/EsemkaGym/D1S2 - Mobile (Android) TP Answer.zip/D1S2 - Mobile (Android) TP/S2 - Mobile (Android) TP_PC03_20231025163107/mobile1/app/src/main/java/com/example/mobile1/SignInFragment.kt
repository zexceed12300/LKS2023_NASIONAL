package com.example.mobile1

import android.os.AsyncTask
import android.os.Bundle
import android.telephony.SignalStrengthUpdateRequest
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.mobile1.Main.Api
import com.example.mobile1.Main.RegisteredFragment
import com.example.mobile1.databinding.ActivityMainBinding
import com.example.mobile1.databinding.FragmentSignInBinding
import org.json.JSONObject
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL


class SignInFragment : Fragment() {
    private lateinit var binding: FragmentSignInBinding
    private lateinit var mainActivity: MainActivity
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentSignInBinding.inflate(layoutInflater)
        mainActivity = (activity as MainActivity)
        binding.apply {
            signUp.setOnClickListener{
                mainActivity.replaceFragment(SignUpFragment(), false)
            }
            button.setOnClickListener{
                mainActivity.replaceFragment(RegisteredFragment(), false)
            }

        }
        return binding.root
    }
    private inner class LoginAsyncTask: AsyncTask<String, Void, String>(){
        val url = Api.api
        override fun doInBackground(vararg params: String?): String {
            val loginUrl = URL("${url}login")
            try {
                val connection = loginUrl.openConnection() as HttpURLConnection
                connection.requestMethod = "POST"

                var body = JSONObject()
                body.put("email", binding.email.text.toString())
                body.put("password", binding.password.text.toString())

                connection.doOutput
                val inputStream = connection.inputStream
                val reader = BufferedReader(inputStream.reader())
                var line: String?



            }catch (e :Exception){
                Log.e("error", e.message!!)
            }
            return url
        }
        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)

        }
    }

}