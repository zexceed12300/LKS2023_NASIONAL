package com.example.android_pc04_sesi_1

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.example.android_pc04_sesi_1.databinding.ActivityMainBinding
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class LoginActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    var isShow : Boolean = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        checktoken()
        binding.btnSignUp.setOnClickListener {
            startActivity(Intent(this, SignUpActivity::class.java))
        }
        binding.btnSignIn.setOnClickListener {
            login()
        }
//        binding.eye.setOnClickListener{
//
//        }

    }
    fun login (){
        val email = binding.txtEmail.text
        val pass = binding.txtPass.text
        val url = URL("http://10.0.2.2:8081/api/login")
        val handler = Handler(Looper.myLooper()!!)
        val body = JSONObject()
        body.put("email", email)
        body.put("password",pass)
        Executors.newSingleThreadExecutor().execute(object :Runnable{
            override fun run() {
                var result = ""
                val koneksi =url.openConnection() as HttpURLConnection
                koneksi.requestMethod = "POST"
                koneksi.addRequestProperty("Content-Type","Application/json")

                val output = OutputStreamWriter(koneksi.outputStream)
                output.write(body.toString())
                output.flush()
                 try {
                     result= koneksi.inputStream.bufferedReader().use { it.readText() }
                 }catch (e:Exception){
                     result = koneksi.errorStream.bufferedReader().use { it.readText() }
                 }
                handler.post(object : Runnable{
                    override fun run() {
                        try {
                            val hasil = JSONObject(result)
                            val token = hasil.getString("token").toString()
                            val user = hasil.getJSONObject("user")
                            val join = user.getString("joinedMemberAt")


                            if(join == "null"){
                                startActivity(Intent(this@LoginActivity, RegisteredActivity::class.java))
                                return
                            }else{
                                val email = user.getString("email").toString()
                                User.token = "Bearer $token"
                                val app = getSharedPreferences(prefs, Context.MODE_PRIVATE)
                                app.edit().putString("token", token).apply()
                                app.edit().putString("email",email).apply()
                                if(email != "admin@gmail.com"){
                                    startActivity(Intent(this@LoginActivity, MemberActivity::class.java))
                                }else{
                                    startActivity(Intent(this@LoginActivity, AdminActivity::class.java))
                                }
                            }



                        }catch (e:Exception){
                            Toast.makeText(this@LoginActivity, result, Toast.LENGTH_SHORT).show()
                        }
                    }
                })
            }
        })
    }
    fun checktoken(){
        val app = getSharedPreferences(prefs, Context.MODE_PRIVATE)
        val token = app.getString("token",null)
        val email = app.getString("email","")
        if(token != null){
            if(email != "admin@gmail.com"){
                startActivity(Intent(this@LoginActivity, MemberActivity::class.java))
            }else{
                startActivity(Intent(this@LoginActivity, AdminActivity::class.java))
            }
        }
    }
    companion object{
        const val prefs = "prefs"
    }
}