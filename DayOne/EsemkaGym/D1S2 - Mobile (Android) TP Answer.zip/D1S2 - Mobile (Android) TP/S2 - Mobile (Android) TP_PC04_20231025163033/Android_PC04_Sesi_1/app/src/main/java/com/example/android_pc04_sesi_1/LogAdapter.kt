package com.example.android_pc04_sesi_1

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.android_pc04_sesi_1.databinding.ItemLogBinding
import java.text.SimpleDateFormat

class LogAdapter(val log : MutableList<Log>) : RecyclerView.Adapter<LogAdapter.ViewHolder>() {
    class ViewHolder(val binding: ItemLogBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(ItemLogBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun getItemCount(): Int {
        return log.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = log[position]

//        val akhirformat = SimpleDateFormat("yyyy-MM-dd")
//        val checkin = akhirformat.format(item.checkIn)
//        val checkout = akhirformat.format(item.checkOut)
        holder.binding.textView14.text = item.checkIn
        holder.binding.textView15.text = item.checkOut
    }
    fun setData(data : List<Log>){
        log.clear()
        log.addAll(data)
        notifyDataSetChanged()
    }

}