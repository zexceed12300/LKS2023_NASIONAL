package com.example.android_pc04_sesi_1

data class Log (
    val checkIn : String,
    val checkOut : String? = null
)