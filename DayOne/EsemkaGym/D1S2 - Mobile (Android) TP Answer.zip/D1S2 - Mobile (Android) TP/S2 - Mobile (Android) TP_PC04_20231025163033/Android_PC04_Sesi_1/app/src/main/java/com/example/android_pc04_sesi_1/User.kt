package com.example.android_pc04_sesi_1

object User {
    var token = ""
}