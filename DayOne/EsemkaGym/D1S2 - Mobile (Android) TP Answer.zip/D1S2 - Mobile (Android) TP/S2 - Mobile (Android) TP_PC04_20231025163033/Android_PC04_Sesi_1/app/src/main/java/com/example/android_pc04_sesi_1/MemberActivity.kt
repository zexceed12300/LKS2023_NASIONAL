package com.example.android_pc04_sesi_1

import android.content.Context
import android.content.Intent
import android.icu.text.SimpleDateFormat
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.android_pc04_sesi_1.databinding.ActivityMemberBinding
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.concurrent.Executors
import kotlin.math.log

class MemberActivity : AppCompatActivity() {
    lateinit var binding: ActivityMemberBinding
    lateinit var itemAdapter: LogAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMemberBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setuplist()
        loadAttendance()
        binding.buttoncheck.setOnClickListener {
            checkIn()
            loadAttendance()
        }
        binding.button.setOnClickListener {

            User.token = ""
            val app = getSharedPreferences(LoginActivity.prefs, Context.MODE_PRIVATE)
            app.edit().remove("token").apply()
            app.edit().remove("email").apply()
            startActivity(Intent(this,  LoginActivity::class.java))
        }

    }
    fun checkIn(){
        val kode = binding.txtkode.text
        val url = URL("http://10.0.2.2:8081/api/attendance/checkin/$kode")
        val handler = Handler(Looper.myLooper()!!)

        Executors.newSingleThreadExecutor().execute(object : Runnable{
            override fun run() {
                var result = ""
                val koneksi = url.openConnection() as HttpURLConnection
                koneksi.requestMethod= "POST"
                koneksi.addRequestProperty("Content-Type","application/json")
                koneksi.addRequestProperty("Authorization", User.token)


                try {
                    result= koneksi.inputStream.bufferedReader().use { it.readText() }
                }catch (e:Exception){
                    result = koneksi.errorStream.bufferedReader().use { it.readText() }
                }
                handler.post(object : Runnable{
                    override fun run() {
                        try {
                            val hasil = JSONObject(result)
                            val checkin = hasil.getString("checkIn")
                            if(checkin != null){
                                Toast.makeText(this@MemberActivity, "Success Check In", Toast.LENGTH_SHORT).show()
                            }
                        }catch (e:Exception){
                            Toast.makeText(this@MemberActivity, result, Toast.LENGTH_SHORT).show()
                        }
                    }
                })
            }
        })
    }

    override fun onStart() {
        super.onStart()
        setuplist()
        loadAttendance()
        val calendar = Calendar.getInstance().time
        val format = SimpleDateFormat("dd MMMM yyyy")
        val formatted = format.format(calendar)
        binding.txttanggal.setText(formatted)
    }
    fun setuplist(){
        itemAdapter = LogAdapter(mutableListOf())
        binding.rvLog.apply {
            layoutManager = LinearLayoutManager(this@MemberActivity)
            adapter = itemAdapter
        }
    }
    fun loadAttendance(){
        val url = URL("http://10.0.2.2:8081/api/attendance")
        val handler = Handler(Looper.myLooper()!!)
        Executors.newSingleThreadExecutor().execute(object :Runnable{
            override fun run() {
                var result = ""
                val koneksi = url.openConnection() as HttpURLConnection
                koneksi.requestMethod = "GET"
                koneksi.addRequestProperty("Authorization", User.token)

                try {
                    result= koneksi.inputStream.bufferedReader().use { it.readText() }
                }catch (e:Exception){
                    result = koneksi.errorStream.bufferedReader().use { it.readText() }
                }
                handler.post(object : Runnable{
                    override fun run() {
                        try {
                            val hasil = JSONArray(result)
                            val loglist = ArrayList<Log>()
                            for(i in 0 until hasil.length()){
                                val obj = hasil.getJSONObject(i)
                                val log = Log(
                                    obj.getString("checkIn"),
                                    obj.getString("checkOut")
                                )
                                loglist.add(log)
                            }
                            itemAdapter.setData(loglist)

                        }catch (e:Exception){
                            Toast.makeText(this@MemberActivity, result, Toast.LENGTH_SHORT).show()
                        }
                    }
                })
            }
        })
    }
}