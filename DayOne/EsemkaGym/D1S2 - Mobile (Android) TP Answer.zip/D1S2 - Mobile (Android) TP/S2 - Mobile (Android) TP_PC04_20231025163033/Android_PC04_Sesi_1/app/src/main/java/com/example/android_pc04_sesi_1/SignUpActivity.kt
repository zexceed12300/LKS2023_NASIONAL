package com.example.android_pc04_sesi_1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.example.android_pc04_sesi_1.databinding.ActivitySignUpBinding
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class SignUpActivity : AppCompatActivity() {
    lateinit var binding: ActivitySignUpBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.txtSignIn.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
        }
        binding.btnSignUp.setOnClickListener {
            signup()
        }
    }
    fun signup(){
        val email = binding.txtEmail.text
        val pass = binding.txtPass.text
        val name = binding.txtName.text
        val gender = if(binding.radioButtonMale.isActivated) "Male" else "Female"
        val url = URL("http://10.0.2.2:8081/api/signup")
        val handler = Handler(Looper.myLooper()!!)
        val body = JSONObject()
        body.put("email", email)
        body.put("gender", gender)
        body.put("name", name)
        body.put("password", pass)
        Executors.newSingleThreadExecutor().execute(object :Runnable{
            override fun run() {
                var result = ""
                val koneksi = url.openConnection() as HttpURLConnection
                koneksi.requestMethod = "POST"
                koneksi.addRequestProperty("Content-Type", "Application/json")

                val output = OutputStreamWriter(koneksi.outputStream)
                output.write(body.toString())
                output.flush()

                try {
                    result= koneksi.inputStream.bufferedReader().use { it.readText() }
                }catch (e:Exception){
                    result = koneksi.errorStream.bufferedReader().use { it.readText() }
                }
                handler.post(object :Runnable{
                    override fun run() {
                        try {
                            val email = JSONObject(result).getString("email")
                            Toast.makeText(this@SignUpActivity, "Registration Complete", Toast.LENGTH_SHORT).show()
                        }catch (e:Exception){
                            Toast.makeText(this@SignUpActivity, result, Toast.LENGTH_SHORT).show()
                        }
                    }
                })
            }
        })
    }
}