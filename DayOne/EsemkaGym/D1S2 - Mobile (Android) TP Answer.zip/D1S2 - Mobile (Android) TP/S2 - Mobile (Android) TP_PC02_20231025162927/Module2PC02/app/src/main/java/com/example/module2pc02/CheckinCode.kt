package com.example.module2pc02

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class CheckinCode : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkin_code)

        val back = findViewById<TextView>(R.id.back)
        back.setOnClickListener {
            onBackPressed()
        }
    }
}