package com.example.module2pc02

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.sign

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val daftar = findViewById<TextView>(R.id.btnSignup)
        daftar.setOnClickListener{
            val intent = Intent(this, Signup::class.java)
            startActivity(intent)
        }

        val txtEmail = findViewById<EditText>(R.id.email)
        val txtPw = findViewById<EditText>(R.id.password)

        val signin = findViewById<Button>(R.id.signin)
        signin.setOnClickListener{
            CoroutineScope(Dispatchers.Main).launch {
                try {
                    val url = "http://10.0.2.2:8081/api/login"
                    val jsonBody = JSONObject()
                    jsonBody.put("email", txtEmail.text)
                    jsonBody.put("password", txtPw.text)

                    val response = Function.httpRequest(url, "POST", jsonBody.toString())
                    if (response != null) {
                        val obj = JSONObject(response)
                        val token = obj.getString("token")
                        val data = obj.getJSONObject("user")
                        val name = data.getString("name")
                        val email = data.getString("email")
                        var admin: Boolean = data.getBoolean("admin")
                        if (admin) {
                            val intent = Intent(this@MainActivity, Adminpanel::class.java)
                            intent.putExtra("name", name)
                            intent.putExtra("email", email)
                            startActivity(intent)

                            Toast.makeText(applicationContext, "Login Succesfull, Welcome $name!", Toast.LENGTH_SHORT).show()
                        }
                        else {
                            val intent = Intent(this@MainActivity, Userpanel::class.java)
                            startActivity(intent)
                            Toast.makeText(applicationContext, "Login Succesfull, Welcome $name!", Toast.LENGTH_SHORT).show()
                        }
                    }
                    else {
                        Toast.makeText(applicationContext, "Login Failed! Incorrect Email or Password", Toast.LENGTH_SHORT).show()
                    }
                }
                catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }
}