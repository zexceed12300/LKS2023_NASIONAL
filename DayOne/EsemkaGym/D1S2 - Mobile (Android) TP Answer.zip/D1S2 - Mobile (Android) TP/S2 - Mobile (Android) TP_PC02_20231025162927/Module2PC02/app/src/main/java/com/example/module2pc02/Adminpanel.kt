package com.example.module2pc02

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.cardview.widget.CardView

class Adminpanel : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_adminpanel)

        val name = intent.getStringExtra("name")
        val email = intent.getStringExtra("email")

        val txtname = findViewById<TextView>(R.id.name)
        val txtemail = findViewById<TextView>(R.id.email)

        txtname.text = name
        txtemail.text = email

        val checkin = findViewById<CardView>(R.id.checkin)
        checkin.setOnClickListener {
            val intent = Intent(this@Adminpanel, CheckinCode::class.java)
            startActivity(intent)
        }

        val btnLogout = findViewById<CardView>(R.id.logout)
        btnLogout.setOnClickListener {
            onBackPressed()
        }

        val manageMember = findViewById<CardView>(R.id.manageMember)
        manageMember.setOnClickListener {
            val intent = Intent(this@Adminpanel, ManageMember::class.java)
            startActivity(intent)
        }
    }
}