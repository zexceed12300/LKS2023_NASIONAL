package com.example.module2pc02

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject

class Signup : AppCompatActivity() {
    private lateinit var txtGender : String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        val login = findViewById<TextView>(R.id.btnSignin)
        login.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        txtGender = String()
        txtGender = "Male"

        val signup = findViewById<Button>(R.id.signup)
        val txtEmail = findViewById<EditText>(R.id.email)
        val txtPw = findViewById<EditText>(R.id.password)
        val txtName = findViewById<EditText>(R.id.name)
        val ggender = findViewById<RadioGroup>(R.id.gender)

        ggender.setOnCheckedChangeListener { radioGroup, i ->
            val gender = ggender.checkedRadioButtonId.toString()
            Log.d("Gender", "${ggender.checkedRadioButtonId} - $gender")
            if (gender == "2131231222") {
                txtGender = "Male"
            } else {
                txtGender = "Female"
            }
        }

        signup.setOnClickListener {
            CoroutineScope(Dispatchers.Main).launch {
                try {
                    val url = "http://10.0.2.2:8081/api/signup"
                    val jsonBody = JSONObject()
                    jsonBody.put("email", txtEmail.text)
                    jsonBody.put("password", txtPw.text)
                    jsonBody.put("name", txtName.text)
                    jsonBody.put("gender", txtGender)

                    val response = Function.httpRequest(url, "POST", jsonBody.toString())
                    if (response != null) {
                        Toast.makeText(applicationContext, "Registration completes! Enter your email and password to login", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this@Signup, MainActivity::class.java)
                        startActivity(intent)
                    }
                    else {
                        Toast.makeText(applicationContext, "Registration Failed!", Toast.LENGTH_SHORT).show()
                    }
                }
                catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }
}