package com.example.esemkagym

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.example.esemkagym.apiservices.ApiServices
import com.example.esemkagym.databinding.ActivityDailyCheckInBinding
import com.example.esemkagym.preferences.AuthPreference
import com.example.esemkagym.util.Constants.TAG
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection

class DailyCheckInActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDailyCheckInBinding

    private lateinit var preference: AuthPreference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDailyCheckInBinding.inflate(layoutInflater)
        setContentView(binding.root)

        preference = AuthPreference(this@DailyCheckInActivity)

        binding.apply {
            CoroutineScope(Dispatchers.IO).launch {
                val req = ApiServices(this@DailyCheckInActivity)
                val res = req.getAttendance()
                if (req.responseCode == HttpURLConnection.HTTP_OK) {
                    Log.d(TAG, "onCreate: ${res}")
                }
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@DailyCheckInActivity, "${req.responseCode}", Toast.LENGTH_SHORT).show()
                }
            }

            tvSignout.setOnClickListener {
                preference.logout()
                val intent = Intent(this@DailyCheckInActivity, LoginActivity::class.java)
                startActivity(intent)
            }
        }
    }

    override fun onBackPressed() {
        //super.onBackPressed()
    }
}