package com.example.esemkagym.models

data class LoginResponse(
    val id: Int,
    val token: String,
)
