package com.example.esemkagym.util

object Constants {

    const val TAG = "EsemkaGYM::::::"

    const val API_BASE_URL = "http://10.0.2.2:8081/api/"
}