package com.example.esemkagym

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.esemkagym.apiservices.ApiServices
import com.example.esemkagym.databinding.ActivityLoginBinding
import com.example.esemkagym.preferences.AuthPreference
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var preferences: AuthPreference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        preferences = AuthPreference(this@LoginActivity)

        binding.apply {

            btnSignin.setOnClickListener {
                CoroutineScope(Dispatchers.IO).launch {
                    val req = ApiServices(this@LoginActivity)
                    val res = req.login(etEmail.text.toString().trim(), etPassword.text.toString().trim())
                    if (req.responseCode == HttpURLConnection.HTTP_OK) {
                        preferences.setToken(res!!.id, res!!.token)
                        val intent = Intent(this@LoginActivity, DailyCheckInActivity::class.java)
                        startActivity(intent)
                    } else {
                        withContext(Dispatchers.Main) {
                            Toast.makeText(this@LoginActivity, "Email or password invalid", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }

            tvSignup.setOnClickListener {
                val intent = Intent(this@LoginActivity, RegisterActivity::class.java)
                startActivity(intent)
            }
        }
    }

    override fun onBackPressed() {
        //super.onBackPressed()
    }
}