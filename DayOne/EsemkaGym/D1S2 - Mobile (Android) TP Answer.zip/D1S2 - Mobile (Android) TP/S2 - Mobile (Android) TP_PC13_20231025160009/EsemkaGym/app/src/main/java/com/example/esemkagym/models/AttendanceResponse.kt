package com.example.esemkagym.models

data class AttendanceResponse(
    val checkin: String,
    val checkout: String,
)
