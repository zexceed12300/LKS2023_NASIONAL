package com.example.esemkagym.apiservices

import android.content.Context
import android.util.Log
import com.example.esemkagym.models.AttendanceResponse
import com.example.esemkagym.models.LoginResponse
import com.example.esemkagym.preferences.AuthPreference
import com.example.esemkagym.util.Constants.API_BASE_URL
import com.example.esemkagym.util.Constants.TAG
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class ApiServices(context: Context) {

    val preference = AuthPreference(context)

    var responseCode: Int? = null
    var errorMessage: String? = null

    suspend fun login(email: String, password: String) : LoginResponse? {
        val endpoint = "login"

        var response: LoginResponse? = null

        withContext(Dispatchers.IO) {
            try {
                val url = URL(API_BASE_URL+endpoint)
                val connection = url.openConnection() as HttpURLConnection
                connection.doInput = true
                connection.doOutput = true
                connection.requestMethod = "POST"
                connection.setRequestProperty("Content-Type", "application/json")

                val reqBody = """
                    {
                        "email": "${email}",
                        "password": "${password}"
                    }
                """.trimIndent()

                val outputStream = connection.outputStream
                val writer = OutputStreamWriter(outputStream)
                writer.write(reqBody)
                writer.flush()
                writer.close()

                if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                    val inputStream = connection.inputStream
                    val res = BufferedReader(InputStreamReader(inputStream)).readText()
                    val jsonObject = JSONObject(res)
                    val jsonObjectUser = jsonObject.getJSONObject("user")

                    response = LoginResponse(
                        id = jsonObjectUser.getInt("id"),
                        token = jsonObject.getString("token"),
                    )
                }
                responseCode = connection.responseCode
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        return response
    }

    suspend fun getAttendance() : List<AttendanceResponse>? {
        val endpoint = "attendance"

        var response: List<AttendanceResponse>? = null

        try {
            withContext(Dispatchers.IO) {
                val url = URL(API_BASE_URL+endpoint)
                val connection = url.openConnection() as HttpURLConnection
                Log.d(TAG, "getAttendance: ${preference.getToken()}")
                connection.setRequestProperty("Authorization", "Bearer ${preference.getToken()}")
                Log.d(TAG, "getAttendance: ${connection.responseCode}")

                if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                    val inputStream = connection.inputStream
                    val res = BufferedReader(InputStreamReader(inputStream)).readText()

                    val data = arrayListOf<AttendanceResponse>()
                    val jsonArray = JSONArray(res)
                    for (i in 0 until jsonArray.length()) {
                        val jsonObject = jsonArray.getJSONObject(i)
                        data.add(
                            AttendanceResponse(
                                checkin = jsonObject.getString("checkIn"),
                                checkout = jsonObject.getString("checkOut")
                            )
                        )
                    }
                    response = data
                }
                responseCode = connection.responseCode
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return response
    }
}