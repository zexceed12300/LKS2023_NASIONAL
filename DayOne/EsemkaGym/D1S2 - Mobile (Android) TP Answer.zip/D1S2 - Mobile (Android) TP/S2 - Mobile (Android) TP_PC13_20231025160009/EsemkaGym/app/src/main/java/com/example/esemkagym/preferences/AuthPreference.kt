package com.example.esemkagym.preferences

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences

class AuthPreference(val context: Context) {
    private fun getSharedPreference() : SharedPreferences {
        return context.getSharedPreferences(PREF_AUTH, Activity.MODE_PRIVATE)
    }

    fun setToken(id: Int, token: String) {
        getSharedPreference().edit().apply {
            putInt(PREF_AUTH_ID, id)
            putString(PREF_AUTH_TOKEN, token)
            apply()
        }
    }

    fun getToken() : String {
        return "Bearer "+getSharedPreference().getString(PREF_AUTH_TOKEN, "")
    }

    fun isTokenExist() : Boolean {
        return getSharedPreference().getString(PREF_AUTH_TOKEN, "")!!.isNotEmpty()
    }

    fun logout() {
        getSharedPreference().edit().apply {
            putInt(PREF_AUTH_ID, 0)
            putString(PREF_AUTH_TOKEN, "")
            apply()
        }
    }

    companion object {
        const val PREF_AUTH = "authPrefs"

        const val PREF_AUTH_ID = "authPrefsId"
        const val PREF_AUTH_TOKEN = "authPrefsToken"
    }
}