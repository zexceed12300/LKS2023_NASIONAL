package com.edhohabun.laptop_11.manage

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.edhohabun.laptop_11.R

class ManageMembersActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_members)
    }
}