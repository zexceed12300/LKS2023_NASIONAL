package com.edhohabun.laptop_11.UI.main

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import com.edhohabun.laptop_11.R

class MainActivity : AppCompatActivity() {


    private  lateinit var inputemail: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}