package com.edhohabun.laptop_11.Checkln

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.edhohabun.laptop_11.R

class DailyCheckInCodeAdmiActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_daily_check_in_code_admi)
    }
}