package com.edhohabun.laptop_11.UI.Login.registerSuccess

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.edhohabun.laptop_11.R

class RegisterSuccessActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_success)
    }
}