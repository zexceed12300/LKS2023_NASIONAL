package com.example.mobile_pc_05.item

data class itemPading (
    val id:String,
    val date:String,
    val name:String
)