package com.example.mobile_pc_05

import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.widget.Toast
import com.example.mobile_pc_05.SharePreft.SharePrfet
import com.example.mobile_pc_05.databinding.ActivitySignUpBinding
import org.json.JSONObject
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class SignUpActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySignUpBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvtoSigin.setOnClickListener {
            startActivity(Intent(this,MainActivity::class.java))
        }

        binding.btnSignIn.setOnClickListener {
            getToken(this).execute()
        }

    }



    private inner class getToken(val context: Context): AsyncTask<String, String, String>() {
        override fun doInBackground(vararg params: String?): String {
            var result = ""
            var gender=""
            val jsonObject = JSONObject()
            /*jsonObject.put("email", "admin@gmail.com")
            jsonObject.put("password", "admin")
            jsonObject.put("name", "admin@gmail.com")*/
            if(binding.rdMale.isChecked==true){
                jsonObject.put("gender","Male")
            }
            if(binding.rdFemale.isChecked==true){
                jsonObject.put("gender","Female")
            }
            jsonObject.put("name", binding.tiNameSignIn.text)
            jsonObject.put("password", binding.tiPasswordSignIn.text)
            jsonObject.put("email", binding.tiEmailSignIn.text)

            Log.e("request",jsonObject.toString())
            val jsonObjectString = jsonObject.toString()
            var httpURLConnection: HttpURLConnection? = null
            try {
                var url = URL("http://10.0.2.2:8081/api/signup")
                httpURLConnection = url.openConnection() as HttpURLConnection
                httpURLConnection.requestMethod = "POST"
                httpURLConnection.addRequestProperty("Content-Type", "application/json")
                httpURLConnection.doOutput = true
                httpURLConnection.doInput = true

                val output = httpURLConnection.outputStream
                val outputStreamReader = OutputStreamWriter(output)
                outputStreamReader.write(jsonObjectString)
                outputStreamReader.flush()

                if (httpURLConnection.responseCode == 400) {
                    Handler(mainLooper).post(Runnable {
                        Toast.makeText(context, "input Tidak Valid", Toast.LENGTH_SHORT)
                            .show()
                    })
                }
                val input = httpURLConnection.inputStream
                val inputStreamReader = InputStreamReader(input)
                var data = inputStreamReader.read()

                while (data != -1) {
                    result += data.toChar()
                    data = inputStreamReader.read()
                }
                val jsonObjectresponse = JSONObject(result)
                /*val token = jsonObjectresponse.getString("token")
                SharePrfet(context).saveToken(token)*/
                Log.e("request",jsonObjectresponse.toString())
            } catch (e: Exception) {
                Log.e("Error Http", "Error $e")
                return ""
            }
            return result
        }

        override fun onPreExecute() {
            super.onPreExecute()
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            if (result != "") {
                startActivity(Intent(context,StatusActivity::class.java))
            }
        }
    }
}