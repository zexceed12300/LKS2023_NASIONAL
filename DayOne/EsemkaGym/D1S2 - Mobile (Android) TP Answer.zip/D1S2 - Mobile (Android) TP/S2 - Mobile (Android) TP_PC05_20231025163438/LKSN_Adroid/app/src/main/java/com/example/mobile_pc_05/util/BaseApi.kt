package com.example.mobile_pc_05.util

object BaseApi {
    const val baseApi="http://10.0.2.2:8081/api/"
}