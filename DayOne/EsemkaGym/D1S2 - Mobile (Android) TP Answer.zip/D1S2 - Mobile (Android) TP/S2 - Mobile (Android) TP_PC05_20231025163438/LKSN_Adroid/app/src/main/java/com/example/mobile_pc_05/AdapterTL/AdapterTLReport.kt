package com.example.mobile_pc_05.AdapterTL

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.example.mobile_pc_05.FramgemtReport.AttandeLogFragment
import com.example.mobile_pc_05.FramgemtReport.GenderChartFragment
import com.example.mobile_pc_05.FramgemtReport.ReportAttandeFragmentFragment

class AdapterTLReport(fm: FragmentManager, val tabitem:Int): FragmentPagerAdapter(fm) {
    override fun getCount(): Int {
        return tabitem
    }

    override fun getItem(position: Int): Fragment {
        return when(position) {
            0 -> ReportAttandeFragmentFragment()
            1 -> GenderChartFragment()
            2 -> AttandeLogFragment()
            else -> getItem(position)
        }
    }
}