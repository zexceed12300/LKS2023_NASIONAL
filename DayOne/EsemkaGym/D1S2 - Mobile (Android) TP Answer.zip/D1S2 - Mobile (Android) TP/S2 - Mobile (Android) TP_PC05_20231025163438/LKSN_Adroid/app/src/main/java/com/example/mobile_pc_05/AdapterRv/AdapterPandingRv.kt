package com.example.mobile_pc_05.AdapterRv

import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.mobile_pc_05.AdminActivity
import com.example.mobile_pc_05.R
import com.example.mobile_pc_05.SharePreft.SharePrfet
import com.example.mobile_pc_05.item.itemPading
import com.example.mobile_pc_05.util.BaseApi
import org.json.JSONArray
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class AdapterPandingRv(val item:List<itemPading>,val context: Context):RecyclerView.Adapter<AdapterPandingRv.ViewHolder> (){
    class ViewHolder(val view: View):RecyclerView.ViewHolder(view) {
        val nama:TextView=view.findViewById(R.id.tvNamePanding)
        val date:TextView=view.findViewById(R.id.tvDatePanding)
        val config:Button=view.findViewById(R.id.btnConfimPanding)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.adapter_pending_rv,parent,false))
    }

    override fun getItemCount(): Int {
        return item.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val items=item[position]
        holder.nama.text=items.name
        holder.date.text=items.date
        holder.config.setOnClickListener {
            postData(context,items.id).execute()
            context.startActivity(Intent(context,AdminActivity::class.java))
        }
    }

    private inner class postData(val context: Context, val id:String): AsyncTask<String, String, List<itemPading>>(){
        override fun doInBackground(vararg params: String?): List<itemPading> {
            var result=""
            var httpURLConnection: HttpURLConnection?=null
            val token="Bearer "+ SharePrfet(context).getToken()
            val datalist= mutableListOf<itemPading>()
            try {
                var url= URL(BaseApi.baseApi+"member/$id/approve")
                httpURLConnection=url.openConnection() as HttpURLConnection
                httpURLConnection.requestMethod="PUT"
                httpURLConnection.addRequestProperty("Authorization",token)
                httpURLConnection.doOutput=true
                httpURLConnection.doInput=true
                httpURLConnection.connect()

                val input=httpURLConnection.inputStream
                val inputStreamReader= InputStreamReader(input)
                var data=inputStreamReader.read()

                while (data!=-1){
                    result+=data.toChar()
                    data=inputStreamReader.read()
                }
                val jsonArray= JSONArray(result)
                Log.e("Http",jsonArray.toString())

            }catch (e:Exception){
                Log.e("Error Http","Error $e")
            }
            return datalist
        }

        override fun onPreExecute() {
            super.onPreExecute()
        }

        override fun onPostExecute(result: List<itemPading>?) {
            super.onPostExecute(result)
        }
    }
}