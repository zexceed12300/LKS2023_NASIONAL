package com.example.mobile_pc_05.FramgmentMember

import android.content.Context
import android.os.AsyncTask
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.recyclerview.widget.RecyclerView
import com.example.mobile_pc_05.AdapterRv.AdapterPandingRv
import com.example.mobile_pc_05.R
import com.example.mobile_pc_05.SharePreft.SharePrfet
import com.example.mobile_pc_05.item.itemPading
import com.example.mobile_pc_05.util.BaseApi
import org.json.JSONArray
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [MPastFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class MPastFragment : Fragment() {
    private lateinit var recyclerView: RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view=inflater.inflate(R.layout.fragment_m_past, container, false)
        recyclerView=view.findViewById(R.id.rvActive)
        val filter=view.findViewById<EditText>(R.id.tiFilterPading)
        getdata(requireContext(),filter.text.toString()).execute()
        filter.setOnClickListener {
            getdata(requireContext(),filter.text.toString()).execute()
        }
        return view
    }
    private inner class getdata(val context: Context, val vilter:String): AsyncTask<String, String, List<itemPading>>(){
        override fun doInBackground(vararg params: String?): List<itemPading> {
            var result=""
            var httpURLConnection: HttpURLConnection?=null
            val token="Bearer "+ SharePrfet(context).getToken()
            val datalist= mutableListOf<itemPading>()
            try {
                var url= URL(BaseApi.baseApi+"member?name=$vilter&status=ACTIVE")
                httpURLConnection=url.openConnection() as HttpURLConnection
                httpURLConnection.requestMethod="GET"
                httpURLConnection.addRequestProperty("Authorization",token)
                httpURLConnection.doInput=true
                httpURLConnection.connect()

                val input=httpURLConnection.inputStream
                val inputStreamReader= InputStreamReader(input)
                var data=inputStreamReader.read()

                while (data!=-1){
                    result+=data.toChar()
                    data=inputStreamReader.read()
                }
                val jsonArray= JSONArray(result)
                Log.e(" Http","Error $jsonArray")

                for (i in 0 until jsonArray.length()){
                    val jsonObject = jsonArray.getJSONObject(i)
                    val id=jsonObject.getString("id")
                    val name=jsonObject.getString("name")
                    val registerAt=jsonObject.getString("registerAt")
                    datalist.add(itemPading(id,registerAt,name))
                }
            }catch (e:Exception){
                Log.e("Error Http","Error $e")
            }
            return datalist
        }

        override fun onPreExecute() {
            super.onPreExecute()
        }

        override fun onPostExecute(result: List<itemPading>?) {
            super.onPostExecute(result)
            val adapter= AdapterPandingRv(result!!,context)
            recyclerView.adapter=adapter
        }
    }
}