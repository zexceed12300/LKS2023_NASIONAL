package com.example.mobile_pc_05.SharePreft

import android.content.ClipData
import android.content.Context
import android.content.SharedPreferences

class SharePrfet constructor(context: Context){
    companion object{
        val shareName="MyApp"
        val shareToken="token"
    }
    val sharePrfet:SharedPreferences=context.getSharedPreferences(shareName,Context.MODE_PRIVATE)

    fun saveToken(data: String){
        sharePrfet.edit().putString(shareToken,data).apply()
    }
    fun getToken():String?{
       return sharePrfet.getString(shareToken,null)
    }
}