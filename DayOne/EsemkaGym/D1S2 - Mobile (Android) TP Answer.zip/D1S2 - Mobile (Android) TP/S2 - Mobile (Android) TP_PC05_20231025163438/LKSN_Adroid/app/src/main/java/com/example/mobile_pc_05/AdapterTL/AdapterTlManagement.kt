package com.example.mobile_pc_05.AdapterTL

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.example.mobile_pc_05.FramgmentMember.MPandingFragment
import com.example.mobile_pc_05.FramgmentMember.MPastFragment
import com.example.mobile_pc_05.FramgmentMember.MactiveFragment
import com.example.mobile_pc_05.databinding.FragmentMPandingBinding

class AdapterTlManagement(fm:FragmentManager,val tabitem:Int):FragmentPagerAdapter(fm) {
    override fun getCount(): Int {
        return tabitem
    }

    override fun getItem(position: Int): Fragment {
            return when(position){
                0->MPastFragment()
                1->MactiveFragment()
                2->MPandingFragment()
                else->getItem(position)
        }
    }

}