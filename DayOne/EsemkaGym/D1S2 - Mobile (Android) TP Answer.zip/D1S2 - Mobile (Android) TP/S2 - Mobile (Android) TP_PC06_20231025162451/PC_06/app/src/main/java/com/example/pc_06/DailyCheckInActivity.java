package com.example.pc_06;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.Executors;

public class DailyCheckInActivity extends AppCompatActivity {
    ArrayList<DateModel> dateModels = new ArrayList<>();
    RecyclerView recIn, recOut;
    TextView txtSignOut;
    EditText txtCheckInCode;
    Button btnCheckIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily_check_in);
        txtSignOut = findViewById(R.id.txtSignOut);
        txtCheckInCode = findViewById(R.id.txtCheckInCode);
        btnCheckIn = findViewById(R.id.btnCheckIn);
        recIn = findViewById(R.id.recViewCheckIn);
        recOut = findViewById(R.id.recViewCheckOut);

        recIn.setLayoutManager(new LinearLayoutManager(DailyCheckInActivity.this));

        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                ResponseDto responseDto = HttpUtils.get("api/attendance", null, false);
                try {
                    JSONArray jsonArray = new JSONArray(responseDto.getJson());
                    for (int i = 0; i < jsonArray.length(); i++){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        dateModels.add(new DateModel(
                                jsonObject.getString("checkIn")
                        ));
                    }
                    DateAdapter dateAdapter = new DateAdapter(dateModels);
                    recIn.post(new Runnable() {
                        @Override
                        public void run() {
                            recIn.setAdapter(dateAdapter);
                        }
                    });
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

        txtSignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DailyCheckInActivity.this, SignIn.class));
                finish();
            }
        });

        btnCheckIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtCheckInCode.getText().toString().trim().length() == 0){
                    HttpUtils.showToast(DailyCheckInActivity.this, "CheckIn code must be fill");
                    return;
                }
                Executors.newSingleThreadExecutor().execute(new Runnable() {
                    @Override
                    public void run() {
                        ResponseDto responseDto = HttpUtils.post("api/attendance/checkin/" + txtCheckInCode.getText().toString(), BaseApplication.token, "");
                        if (responseDto.getCode() == 200){
                            HttpUtils.showToast(DailyCheckInActivity.this,"CheckIn Success");
                            return;
                        }
                        HttpUtils.showToast(DailyCheckInActivity.this,"CheckIn Code not found");
                    }
                });
            }
        });
    }
}