package com.example.pc_06;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.Executors;

public class SignUpActivity extends AppCompatActivity {

    TextView txtSignIn;
    TextInputEditText email, password, name;
    Button btnSignUp;
    RadioButton rbMale, rbFemale;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        txtSignIn = findViewById(R.id.txtSignIn);
        btnSignUp = findViewById(R.id.btn_SignUp);
        email = findViewById(R.id.TxtEmail);
        password = findViewById(R.id.TxtPassword);
        name = findViewById(R.id.TxtName);
        rbMale = findViewById(R.id.rbMale);
        rbFemale = findViewById(R.id.rbFemale);
        txtSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignUpActivity.this, SignIn.class));
                finish();
            }
        });
        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Executors.newSingleThreadExecutor().execute(new Runnable() {
                    @Override
                    public void run() {
                        JSONObject jsonObject = new JSONObject();
                        try {
                            jsonObject.put("email", email.getText().toString());
                            if (rbMale.isChecked()){
                                jsonObject.put("gender", "Male");
                            }else {
                                jsonObject.put("gender", "Female");
                            }
                            jsonObject.put("name", name.getText().toString());
                            jsonObject.put("password", password.getText().toString());
                            ResponseDto responseDto = HttpUtils.post("api/signup", null, jsonObject.toString());
                            if (responseDto.getCode() == 200){
                                startActivity(new Intent(SignUpActivity.this, DailyCheckInActivity.class));
                                startActivity(new Intent(SignUpActivity.this, RegisteredActivity.class));
                                finish();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });
    }
}