package com.example.pc_06;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.Executors;

public class SignIn extends AppCompatActivity {
    private static final String TAG = "SignIn";
    Button btnSignIn, btnSignUp;
    TextInputEditText email, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);
        btnSignIn = findViewById(R.id.btnSignIn);
        btnSignUp = findViewById(R.id.btnSignUp);
        email = findViewById(R.id.txtEmail);
        password = findViewById(R.id.txtPassword);
//        email.setText("ada.lovelace@gmail.com");
//        password.setText("ada.lovelace");
//        email.setText("admin@gmail.com");
//        password.setText("admin");

        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (email.getText().toString().trim().length() == 0 || password.getText().toString().trim().length() == 0){
                    HttpUtils.showToast(SignIn.this, "Email and Password must be fill");
                }
                Executors.newSingleThreadExecutor().execute(new Runnable() {
                    @Override
                    public void run() {
                        JSONObject auth = new JSONObject();
                        try {
                            auth.put("email", email.getText());
                            auth.put("password", password.getText());
                            ResponseDto responseDto = HttpUtils.post("api/login", null, auth.toString());
                            if (responseDto.getCode() == 200){
                                JSONObject jsonObject = new JSONObject(responseDto.getJson());
                                BaseApplication.token = jsonObject.getString("token");
                                Log.d(TAG, "token: " + BaseApplication.token);
                                Boolean isAdmin = jsonObject.getJSONObject("user").getBoolean("admin");
                                if (isAdmin){
                                    startActivity(new Intent(SignIn.this, DailyCheckInCodeActivity.class));
                                    finish();
                                    return;
                                }
                                startActivity(new Intent(SignIn.this, DailyCheckInActivity.class));
                                finish();
                                return;
                            }
                            HttpUtils.showToast(SignIn.this, "Email or Password wrong");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignIn.this, SignUpActivity.class));
                finish();
            }
        });
    }
}