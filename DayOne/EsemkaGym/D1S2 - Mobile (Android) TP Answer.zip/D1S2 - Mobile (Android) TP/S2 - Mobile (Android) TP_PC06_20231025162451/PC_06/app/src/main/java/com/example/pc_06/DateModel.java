package com.example.pc_06;

import java.util.Date;

public class DateModel {
    String date;

    public DateModel(String date) {
        this.date = date;
    }

    public String getDate() {
        return date;
    }
}
