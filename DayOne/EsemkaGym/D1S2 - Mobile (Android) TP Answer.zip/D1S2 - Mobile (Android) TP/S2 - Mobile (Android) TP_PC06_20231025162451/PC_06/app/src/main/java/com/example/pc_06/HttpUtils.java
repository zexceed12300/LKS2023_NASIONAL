package com.example.pc_06;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.stream.Collectors;

public class HttpUtils {
    private static final String TAG = "HttpUtils";
    private static final String BASE_URL = "http://10.0.2.2:8081/";
    public static ResponseDto get(String endpoint, String token, boolean isFile){
        int code = 400;
        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(BASE_URL+endpoint).openConnection();

            if (token != null){
                connection.addRequestProperty("Authorization", "Bearer " + token);
            }

            code = connection.getResponseCode();
            Log.d(TAG, "get; code: " + code);

            return new ResponseDto(new BufferedReader(new InputStreamReader(connection.getInputStream())).lines().collect(Collectors.joining()), code);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new ResponseDto("", code);
    }
    public static ResponseDto post(String endpoint, String token, String json){
        int code = 400;
        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(BASE_URL+endpoint).openConnection();
            connection.addRequestProperty("content-type", "application/json");
            connection.setRequestMethod("POST");

            if (token != null){
                connection.addRequestProperty("Authorization", "Bearer " + token);
            }

            DataOutputStream dataOutputStream = new DataOutputStream(connection.getOutputStream());
            dataOutputStream.writeBytes(json);
            dataOutputStream.flush();

            code = connection.getResponseCode();
            Log.d(TAG, "post; code: " + code);

            return new ResponseDto(new BufferedReader(new InputStreamReader(connection.getInputStream())).lines().collect(Collectors.joining()), code);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new ResponseDto("", code);
    }
    public static ResponseDto put(String endpoint, String token, String json){
        int code = 400;
        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(BASE_URL+endpoint).openConnection();
            connection.addRequestProperty("content-type", "application/json");
            connection.setRequestMethod("PUT");

            if (token != null){
                connection.addRequestProperty("Authorization", "Bearer " + token);
            }

            DataOutputStream dataOutputStream = new DataOutputStream(connection.getOutputStream());
            dataOutputStream.writeBytes(json);
            dataOutputStream.flush();

            code = connection.getResponseCode();
            Log.d(TAG, "post; code: " + code);

            return new ResponseDto(new BufferedReader(new InputStreamReader(connection.getInputStream())).lines().collect(Collectors.joining()), code);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new ResponseDto("", code);
    }

    public static void showToast(Context context, String msg){
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
