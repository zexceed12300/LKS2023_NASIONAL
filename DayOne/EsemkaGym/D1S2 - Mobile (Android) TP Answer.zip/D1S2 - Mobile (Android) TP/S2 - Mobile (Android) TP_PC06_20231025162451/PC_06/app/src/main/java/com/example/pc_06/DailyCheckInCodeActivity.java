package com.example.pc_06;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.Executors;

public class DailyCheckInCodeActivity extends AppCompatActivity {

    TextView txtCode;
    TextView txtMembers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily_check_in_code);
        txtCode = findViewById(R.id.txtCode);
        txtMembers = findViewById(R.id.txtMembers);
        txtMembers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DailyCheckInCodeActivity.this, ManageMembersActivity.class));
            }
        });
        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                ResponseDto responseDto = HttpUtils.get("api/attendance/checkin/code", BaseApplication.token, false);
                try {
                    JSONObject jsonObject = new JSONObject(responseDto.getJson());
                    txtCode.post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                txtCode.setText(jsonObject.getString("code"));
                            } catch (JSONException e) {
                                throw new RuntimeException(e);
                            }
                        }
                    });
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}