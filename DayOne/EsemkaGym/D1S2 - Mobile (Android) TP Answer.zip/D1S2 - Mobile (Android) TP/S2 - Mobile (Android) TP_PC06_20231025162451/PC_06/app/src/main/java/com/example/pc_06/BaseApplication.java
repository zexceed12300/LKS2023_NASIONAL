package com.example.pc_06;

import android.app.Application;

public class BaseApplication extends Application {
    public static String token;
}
